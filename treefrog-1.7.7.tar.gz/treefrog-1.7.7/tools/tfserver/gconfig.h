#ifndef GCONFIG_H
#define GCONFIG_H

/* Namespace for Google classes */
#define GOOGLE_NAMESPACE google

/* Stops putting the code inside the Google namespace */
#define _END_GOOGLE_NAMESPACE_ }

/* Puts following code inside the Google namespace */
#define _START_GOOGLE_NAMESPACE_ namespace google {

#endif // GCONFIG
