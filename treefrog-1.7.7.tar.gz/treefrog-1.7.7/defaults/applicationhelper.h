#ifndef APPLICATIONHELPER_H
#define APPLICATIONHELPER_H

#include <TGlobal>


class T_HELPER_EXPORT ApplicationHelper
{
};

#endif // APPLICATIONHELPER_H
