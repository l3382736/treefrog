/* Copyright (c) 2010-2013, AOYAMA Kazuharu
 * All rights reserved.
 *
 * This software may be used and distributed according to the terms of
 * the New BSD License, which is incorporated herein by reference.
 */

#include <TCriteriaConverter>
#include <QAtomicPointer>

/*!
 * \class TCriteriaConverter<>
 * \brief The TCriteriaConverter class is a template class that converts
 * TCriteria objects to SQL strings.
 * This class is for internal use only.
 * \sa TCriteria
 */

class FormatHash : public QHash<int, QString>
{
public:
    FormatHash() : QHash<int, QString>()
    {
        insert(TSql::Equal, "=%1");
        insert(TSql::NotEqual, "<>%1");
        insert(TSql::LessThan, "<%1");
        insert(TSql::GreaterThan, ">%1");
        insert(TSql::LessEqual, "<=%1");
        insert(TSql::GreaterEqual, ">=%1");
        insert(TSql::IsNull, " IS NULL");
        insert(TSql::IsNotNull, " IS NOT NULL");
        insert(TSql::Like, " LIKE %1");
        insert(TSql::NotLike, " NOT LIKE %1");
        insert(TSql::LikeEscape, " LIKE %1 ESCAPE %2");
        insert(TSql::NotLikeEscape, " NOT LIKE %1 ESCAPE %2");
        insert(TSql::ILike, " ILIKE %1");
        insert(TSql::NotILike, " NOT ILIKE %1");
        insert(TSql::ILikeEscape, " ILIKE %1 ESCAPE %2");
        insert(TSql::NotILikeEscape, " NOT ILIKE %1 ESCAPE %2");
        insert(TSql::In, " IN (%1)");
        insert(TSql::NotIn, " NOT IN (%1)");
        insert(TSql::Between, " BETWEEN %1 AND %2");
        insert(TSql::NotBetween, " NOT BETWEEN %1 AND %2");
        insert(TSql::Any, "ANY (%1)");
        insert(TSql::All, "ALL (%1)");
    }
};
Q_GLOBAL_STATIC(FormatHash, formatHash)


const QHash<int, QString> &TSql::formats()
{
    return *formatHash();
}
