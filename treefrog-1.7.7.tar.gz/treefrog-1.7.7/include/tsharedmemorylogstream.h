#include "../src/tsharedmemorylogstream.h"
