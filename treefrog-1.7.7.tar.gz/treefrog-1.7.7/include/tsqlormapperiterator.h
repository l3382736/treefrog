#include "../src/tsqlormapperiterator.h"
