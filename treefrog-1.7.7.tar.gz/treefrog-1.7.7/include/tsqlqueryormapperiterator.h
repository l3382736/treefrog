#include "../src/tsqlqueryormapperiterator.h"
